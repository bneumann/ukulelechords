package com.newbucket.ukulelechords;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;

/**
 * Created by benni on 18.10.2015.
 */
public class TestUtils
{
    public static ArrayList<String[]> testAutomaticChords(String[] aChordIn)
    {
        ArrayList<String[]> ret = new ArrayList<>();
        Chord chord = new Chord(aChordIn);

        ArrayList<String> cNotes = new ArrayList<>();
        for(Note n : chord.getNotes())
        {
            cNotes.add(n.toString());
        }

        String[] aChordOut = cNotes.toArray(new String[cNotes.size()]);
        Arrays.sort(aChordOut);
        aChordOut = new HashSet<>(Arrays.asList(aChordOut)).toArray(new String[0]);
        Arrays.sort(aChordIn);
        aChordIn = new HashSet<>(Arrays.asList(aChordIn)).toArray(new String[0]);
        ret.add(aChordIn);
        ret.add(aChordOut);
        return ret;
    }
}
