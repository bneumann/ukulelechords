package com.newbucket.controls;

/**
 * Created by benni on 01.11.2015.
 */
public class PieView
{
}
