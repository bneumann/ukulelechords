# Ukulele Chords for Android
A chordfinder app for Android with an easy interface. It is still WIP but the basics work and I am improving the interface to have something like a pie selector

# Screenshots
<img alt="Classic G Chord" src="screenshots/g_chord.png" width="300"><br/>
A "G" Chord

<img alt="Classic Gm7 Chord" src="screenshots/gm7_chord.png" width="300"><br/>
A "Gm7" Chord
